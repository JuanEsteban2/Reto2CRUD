﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace capa_logica
{
    public class Clase_Logica
    {
        public int codigo { get; set; }
        public String titulo { get; set; }
        public String autor { get; set; }
        public String editorial { get; set; }
        public int precio { get; set; }
        public int cantidad { get; set; }
        public String accion { get; set; }
    }
}
